#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main(){
    pid_t a = fork();

    if (a < 0) {
        perror("error in fork\n");
        return 1;
    }

    else if (a == 0) {
        pid_t b = fork();

        if (b < 0) {
            perror("error in fork\n");
            return 1;
        }

        else if (b == 0) {
            printf("I am grandchild\n");
        }

        else {
            wait(NULL);
            printf("I am child\n");
        }
    }

    else {
        wait(NULL);
        printf("I am parent\n");
    }
}

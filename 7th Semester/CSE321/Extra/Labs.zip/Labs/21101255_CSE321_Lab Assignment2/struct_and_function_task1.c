#include <stdio.h>

struct bill {
    float quantity;
    float unitPrice;
};

int main() {

    struct bill paratha;
    struct bill vegetable;
    struct bill mineralWater;

    printf("Quantity Of Paratha: ");
    scanf("%f", &paratha.quantity);
    printf("Unit Price: ");
    scanf("%f", &paratha.unitPrice);

    printf("Quantity Of Vegetables: ");
    scanf("%f", &vegetable.quantity);
    printf("Unit Price: ");
    scanf("%f", &vegetable.unitPrice);

    printf("Quantity Of Mineral Water: ");
    scanf("%f", &mineralWater.quantity);
    printf("Unit Price: ");
    scanf("%f", &mineralWater.unitPrice);

    int numberOfPeople;
    printf("Number of People: ");
    scanf("%d", &numberOfPeople);

    float totalBill = (paratha.quantity * paratha.unitPrice) + (vegetable.quantity * vegetable.unitPrice) + (mineralWater.quantity * mineralWater.unitPrice);
    
    float costPerPerson = (totalBill / numberOfPeople);
    
    printf("\nOutput:\n");
    printf("Individual people will pay: %f tk\n", costPerPerson);
}
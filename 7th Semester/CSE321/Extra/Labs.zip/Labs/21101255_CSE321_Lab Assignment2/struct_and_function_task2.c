#include <stdio.h>

int main() {
    int a, b;
    int sum = 0;
    
    printf("Enter the Range:\n");
    scanf("%d %d",  &a, &b);
    
    printf("\n");
    printf("Perfect Numbers:\n");

    for (int i = a; i <= b; i++) {
        sum = 0;
        for (int j = 1; j < i; j++) {
            if (i % j == 0) {
                sum += j;
            }
        }

        if (sum == i) {
            printf("%d\n", i);
        }
    }
}

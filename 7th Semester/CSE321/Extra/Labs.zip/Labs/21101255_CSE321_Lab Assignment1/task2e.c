#include <stdio.h>
#include <string.h>

int main() 
{
    char s[100];

    printf("Enter the word: ");
    scanf("%s", s);
    
    int first = 0;
    int last = strlen(s) - 1;
    int palindrome = 1;

    while (first < last) {
        if (s[first] != s[last]) {
            palindrome = 0;
        }
        else{
            palindrome = 1;
        }
        first++; 
        last--; 
    }


    if (palindrome) 
    {
        printf("Palindrome\n");
    } 
    
    else {
        printf("Not Palindrome\n");
    }

}

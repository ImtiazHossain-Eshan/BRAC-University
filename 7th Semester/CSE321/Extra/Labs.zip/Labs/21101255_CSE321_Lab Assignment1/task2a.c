#include <stdio.h>

int main() {
    int num1;
    int num2;
    int result;

    printf("Enter Two Numbers:");
    scanf("%d %d", &num1, &num2);

    if (num1 > num2) {
        result = (num1 - num2);
        printf("%d is greater than %d \n", num1, num2);
        printf("Result of (%d - %d) = %d \n", num1, num2, result);
    } 
    
    else if (num1 < num2) {
        printf("%d is less than %d \n", num1, num2);
        result = (num1 + num2);
        printf("Result of (%d + %d) = %d \n", num1, num2, result);
    } 
    
    else if (num1 == num2) {
        printf("%d is equal to %d \n", num1, num2);
        result = (num1 * num2);
        printf("Result of (%d * %d) = %d \n", num1, num2, result);
    }

}

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <string.h>
#include <sys/msg.h>
#include <sys/wait.h>

struct msg {
    long int type;
    char txt[6];
};

int main() {

    key_t key = ftok("msgQueue", 'b'); 
    char workspaceBuff[100];       
    struct msg message;
    int msgQueueID = msgget(key, IPC_CREAT | 0666);

    if (msgQueueID == -1) {
        perror("msgget");
        exit(EXIT_FAILURE);
    }

    printf("Please enter the workspace name: \n");
    scanf("%s", workspaceBuff);

    if (strcmp(workspaceBuff, "cse321") != 0) {
        printf("Invalid workspace name\n");
    } 
    
    else {
        strcpy(message.txt, workspaceBuff);
        message.type = 1;
        printf("Workspace name sent to OTP generator from log in: %s\n", message.txt);

        if (msgsnd(msgQueueID, &message, sizeof(message) - sizeof(long), 0) == -1) {
            perror("msgsnd");
            exit(EXIT_FAILURE);
        }

        pid_t a = fork();
        if (a == -1) {
            perror("fork");
            exit(EXIT_FAILURE);
        }

        if (a == 0) { 
            struct msg rec1, send1;

            if (msgrcv(msgQueueID, &rec1, sizeof(rec1) - sizeof(long), 1, 0) == -1) {
                perror("msgrcv");
                exit(EXIT_FAILURE);
            }
            printf("\nOTP generator received workspace name from log in: %s\n", rec1.txt);

            pid_t getPID = getpid();
            sprintf(send1.txt, "%d", getPID);
            send1.type = 2;
            printf("\nOTP sent to log in from OTP generator: %s\n", send1.txt);

            if (msgsnd(msgQueueID, &send1, sizeof(send1) - sizeof(long), 0) == -1) {
                perror("msgsnd");
                exit(EXIT_FAILURE);
            }

            pid_t b = fork();
            if (b == -1) {
                perror("fork");
                exit(EXIT_FAILURE);
            }

            if (b == 0) { 
                struct msg rec1, send1;

                if (msgrcv(msgQueueID, &rec1, sizeof(rec1) - sizeof(long), 3, 0) == -1) {
                    perror("msgrcv");
                    exit(EXIT_FAILURE);
                }
                printf("Mail received OTP from OTP generator: %s\n", rec1.txt);
                strcpy(send1.txt, rec1.txt);
                send1.type = 4;
                printf("OTP sent to log in from mail: %s\n", send1.txt);

                if (msgsnd(msgQueueID, &send1, sizeof(send1) - sizeof(long), 0) == -1) {
                    perror("msgsnd");
                    exit(EXIT_FAILURE);
                }

                return 0; 
            }

            send1.type = 3;
            if (msgsnd(msgQueueID, &send1, sizeof(send1) - sizeof(long), 0) == -1) {
                perror("msgsnd");
                exit(EXIT_FAILURE);
            }
            printf("OTP sent to mail from OTP generator: %s\n", send1.txt);
            return 0; 
        }

        wait(NULL);

        struct msg rec1;

        if (msgrcv(msgQueueID, &rec1, sizeof(rec1) - sizeof(long), 2, 0) == -1) {
            perror("msgrcv");
            exit(EXIT_FAILURE);
        }
        printf("Log in received OTP from OTP generator: %s\n", rec1.txt);

        char otpBuff[6];
        strcpy(otpBuff, rec1.txt);

        if (msgrcv(msgQueueID, &rec1, sizeof(rec1) - sizeof(long), 4, 0) == -1) {
            perror("msgrcv");
            exit(EXIT_FAILURE);
        }
        printf("Log in received OTP from mail: %s\n", rec1.txt);

        if (strcmp(otpBuff, rec1.txt) == 0) {
            printf("OTP Verified\n");
        } 
        else {
            printf("OTP Incorrect\n");
        }

        if (msgctl(msgQueueID, IPC_RMID, NULL) == -1) {
            perror("msgctl");
            exit(EXIT_FAILURE);
        }
    }

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
// #include <fcntl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>

struct shared {
    char sel[100];
    int b;
};

int main() {

    pid_t a;
    int fd[2];
    int sm_id;
    int p = pipe(fd);
    struct shared *shm_ptr;

    char buff[999];
    char thanks[999];

    sm_id = shmget((key_t)101, 1024, 0666 | IPC_CREAT);
    shm_ptr = shmat(sm_id, NULL, 0);

    if (p == -1) {
        perror("pipe\n");
    }

    a = fork();
    if (a < 0) {
        perror("fork\n");

    } 
    
    // Parent process
    else if (a > 0) { 
        close(fd[0]);
        int amount;
        shm_ptr->b += 1000;
        printf("Provide Your Input From Given Options:\n1. Type a to Add Money\n2. Type w to Withdraw Money\n3. Type c to Check Balance\n");
        
        scanf("%s", shm_ptr->sel);
        printf("Your selection: %s\n\n", shm_ptr->sel);

        if (strcmp(shm_ptr->sel, "a") == 0) {
            printf("Enter amount to be added:\n");
            scanf("%d", &amount);
            
            if (amount > 0) {
                shm_ptr->b += amount;
                printf("Balance added successfully\nUpdated balance after addition:\n%d\n", shm_ptr->b);
            }
            else {
                printf("Adding failed, Invalid amount\n");
            }
        } 
        
        else if (strcmp(shm_ptr->sel, "w") == 0) {
            printf("Enter amount to be withdrawn:\n");
            scanf("%d", &amount);
            
            if (amount > 0) {
                shm_ptr->b -= amount;
                printf("Balance withdrawn successfully\nUpdated balance after withdrawal:\n%d\n", shm_ptr->b);
            }
            else {
                printf("Withdrawal failed, Invalid amount\n");
            }
        } 
        
        else if (strcmp(shm_ptr->sel, "c") == 0) {
            printf("Your current balance is:\n%d\n", shm_ptr->b);
        } 
        
        else {
            printf("Invalid selection\n");
        }

        strcpy(thanks, "Thank you for using");
        write(fd[1], thanks, sizeof(thanks));
        close(fd[1]);
    } 
    
    // Child process
    else {  
        close(fd[1]);
        read(fd[0], buff, sizeof(buff));
        printf("%s\n", buff);
        shmdt(shm_ptr);
        shmctl(sm_id, IPC_RMID, NULL);
        close(fd[0]);
    }

    return 0;
}

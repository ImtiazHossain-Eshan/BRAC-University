#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define MAX 10 // producers and consumers can produce and consume upto MAX
#define BUFLEN 6
#define NUMTHREAD 2 /* number of threads */

void *consumer(void *id);
void *producer(void *id);

char buffer[BUFLEN];
char source[BUFLEN]; // from this array producer will store it's production into buffer
int buflen;
int buffer_index = 0; // index of the next item to be produced/consumed

// initializing pthread mutex and condition variables
pthread_mutex_t count_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t nonEmpty = PTHREAD_COND_INITIALIZER;
pthread_cond_t full = PTHREAD_COND_INITIALIZER;
int thread_id[NUMTHREAD] = {0, 1};

int main() {
    pthread_t thread[NUMTHREAD];
    char ch[6] = {'a', 'b', 'c', 'd', 'e', 'f'};
    strcpy(source, ch);
    buflen = strlen(source);

    pthread_mutex_init(&count_mutex, NULL);

    pthread_create(&thread[0], NULL, producer, &thread_id[0]);
    pthread_create(&thread[1], NULL, consumer, &thread_id[1]);
    
    pthread_join(thread[0], NULL);
    pthread_join(thread[1], NULL);

    pthread_mutex_destroy(&count_mutex);

    return 0;
}

void *producer(void *id) {
    int thread_id = *(int *)id;
    int producerCount = 0;

    while (producerCount < MAX) {
        pthread_mutex_lock(&count_mutex);
        while (buffer_index >= BUFLEN)
            pthread_cond_wait(&full, &count_mutex);

        buffer[buffer_index] = source[buffer_index];
        printf("%d produced %c by Thread %d\n", producerCount, buffer[buffer_index], thread_id);
        buffer_index++;
        producerCount++;
        pthread_cond_signal(&nonEmpty);
        pthread_mutex_unlock(&count_mutex);
        sleep(0.5);
    }
    pthread_exit(NULL);
}

void *consumer(void *id) {
    int thread_id = *(int *)id;
    int consumerCount = 0;

    while (consumerCount < MAX) {
        pthread_mutex_lock(&count_mutex);
        while (buffer_index <= 0)
            pthread_cond_wait(&nonEmpty, &count_mutex);
        char storeBuff = buffer[buffer_index - 1];
        printf("%d consumed %c by Thread %d\n", consumerCount, storeBuff, thread_id);
        buffer_index--;
        consumerCount++;
        pthread_cond_signal(&full);
        pthread_mutex_unlock(&count_mutex);
        sleep(0.5);
    }
    pthread_exit(NULL);
}

#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
/*
This program provides a possible solution using mutex and semaphore.
use 5 Farmers and 5 ShopOwners to demonstrate the solution.
*/
#define MaxCrops 5 // Maximum crops a Farmer can produce or a Shpoowner can take
#define warehouseSize 5 // Size of the warehouse
sem_t empty;
sem_t full;
int in = 0;
int out = 0;
char crops[warehouseSize]={'R','W','P','S','M'}; //indicating room for different crops
char warehouse[warehouseSize]={'N','N','N','N','N'}; //initially all the room is empty
pthread_mutex_t mutex;

void *Farmer(void *far){
	
	int farID = *(int *)far;
	int count = 0; 
	char fChar; 
	
	while (count <= MaxCrops){
		sem_wait(&empty);
		pthread_mutex_lock(&mutex);
		fChar = crops[in];
		warehouse[in] = crops[in];
		printf("Farmer %d: Inserts Crop %c at %d\n",farID,fChar,count);

		in = (in+1)%warehouseSize;
        	count++;

		sem_post(&full);
		pthread_mutex_unlock(&mutex);
	}
	
	printf("Farmer%d: ",farID);
	for (int i = 0; i < warehouseSize; i++) {
            printf("%c", warehouse[i]);
        }
        printf("\n");
	
}

	
void *ShopOwner(void *sho)
{
	int shID = *(int *)sho;
	int countt=0; 
	char schar;
	
	while (countt <= MaxCrops){
		sem_wait(&full);
		pthread_mutex_lock(&mutex);
		schar = crops[out];
		printf("Shop owner %d: Removes crops %c from %d\n",shID,schar,countt);
		
		warehouse[out] = 'N';
		out = (out+1)%warehouseSize;
		countt++;

		sem_post(&empty);
		pthread_mutex_unlock(&mutex);
	}
	
	printf("ShopOwner%d: ",shID);
	for (int i = 0; i < warehouseSize; i++) {
            printf("%c", warehouse[i]);
        }
        printf("\n");
}


int main(){

/*initializing thread,mutex,semaphore
*/
	pthread_t Far[5],Sho[5];
	pthread_mutex_init(&mutex, NULL);
	sem_init(&empty,0,warehouseSize);//when the warehouse is full thread will wait
	sem_init(&full,0,0);//when the warehouse is empty thread will wait
	int a[5] = {1,2,3,4,5}; //Just used for numbering the Farmer and ShopOwner
	/*create 5 thread for Farmer 5 thread for ShopOwner*/
	
	pthread_t farID[5], shopowner_ID[5];

	for (int i = 0; i < 5; i++){
		pthread_create(&farID[i], NULL, (void *)Farmer, &a[i]);
	}

	for (int j = 0; j < 5; j++){
		pthread_create(&shopowner_ID[j], NULL, (void *)ShopOwner, &a[j]);
	}

	for (int k = 0; k < 5; k++){
		pthread_join(farID[k], NULL);
	}

	for (int l = 0; l < 5; l++){
		pthread_join(shopowner_ID[l], NULL);
	}

	// Closing or destroying mutex and semaphore
	pthread_mutex_destroy(&mutex);
	sem_destroy(&empty);
	sem_destroy(&full);

	return 0;

}
